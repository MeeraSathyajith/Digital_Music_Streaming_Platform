import java.util.ArrayList;
import java.util.List;
@SuppressWarnings("unused")


class DSALinkedList
{
    LLNode head = null;

    void insertBeg(String data)
    {
        LLNode newNode = new LLNode(data);

        if(head == null)
        {
            head = newNode;
            return;
        }

        newNode.next = head;
        head = newNode;
    }

    void insertEnd(String data)
    {
        LLNode newNode = new LLNode(data);
        LLNode temp = head;

        if(head == null)
        {
            insertBeg(data);
            return;
        }

        while(temp.next != null)
        {
            temp = temp.next;
        }

        temp.next = newNode;
    }

    void insertAt(String data, int position)
    {
        LLNode temp = head;
        LLNode newNode = new LLNode(data);

        if (position < 0 || position > this.listSize() + 1)
        {
            throw new IndexOutOfBoundsException("Invalid position");
        }

        if (position == 0)
        {
            this.insertBeg(data);
            return;
        }

        if (position == this.listSize() + 1)
        {
            this.insertEnd(data);
            return;
        }

        for (int i = 0; i < position - 1; i++)
        {
            temp = temp.next;
        }

        newNode.next = temp.next;
        temp.next = newNode;
    }

    int listSize()
    {
        LLNode temp = head;
        int count = 0;

        while (temp.next != null)
        {
            temp = temp.next;
            count++;
        }

        return count;
    }
    
    String getValueAt(int position)
    {
        LLNode temp = head;

        if (position < 0 || position > this.listSize())
        {
            throw new IndexOutOfBoundsException("Invalid position");
        }

        for (int i = 0; i < position; i++)
        {
            temp = temp.next;
        }

        return temp.data;
    }

    String getValueAt1(int position)
    {
        LLNode temp = head;
        int count = 0;

        if (position < 0)
        {
            throw new IndexOutOfBoundsException("Invalid position (Less than 0)");
        }

        while (count != position && temp.next != null)
        {
            temp = temp.next;
            count++;
        }

        if (temp.next == null)
        {
            if (count != position)
            {
                throw new IndexOutOfBoundsException("Invalid position (More than list size)");
            }
        }

        return temp.data;
    }

    void deleteAt(int position)
    {
        LLNode temp = head;
        LLNode prev = temp;
        int count = 0;

        if (position < 0)
        {
            throw new IndexOutOfBoundsException("Invalid position (Less than 0)");
        }

        if (position == 0)
        {
            this.deleteBeg();
            return;
        }

        for (int i = 0; i < position; i++)
        {
            prev = temp;
            temp = temp.next;
            if (temp == null) break;
            count++;
        }

        if (temp == null || temp.next == null)
        {
            if (count != position)
            {
                throw new IndexOutOfBoundsException("Invalid position (More than list size)");
            }
        }

        prev.next = temp.next;
    }

    int searchValuePos(String value)
    {
        LLNode temp = head;
        int count = 0;

        while (temp.next != null && temp.data != value)
        {
            temp = temp.next;
            count++;
        }

        if (temp.next == null)
        {
            if (temp.data == value)
            {
                return count;
            }
            
            throw new Error("Value not found");
        }

        return count;
    }

    String searchValue(String value)
    {
        int position = this.searchValuePos(value);
        String element = this.getValueAt(position);

        return element;
    }

    void deleteValue(String value)
    {
        int position = this.searchValuePos(value);

        this.deleteAt(position);
    }

    void deleteBeg()
    {
        if (this.head == null)
        {
            System.out.println("Nothing to delete");
            return;
        }

        this.head = this.head.next;
    }

    void deleteEnd()
    {
        LLNode temp = head;
        LLNode prev = temp;

        if (head == null || head.next == null)
        {
            this.deleteBeg();
            return;
        }

        while (temp.next != null)
        {
            prev = temp;
            temp = temp.next;
        }

        prev.next = null;
    }

    List<String> getAllData()
    {
        LLNode temp = head;
        List<String> allData = new ArrayList<>();

        if (this.head == null)
        {
            return allData;
        }

        while (temp.next != null)
        {
            allData.add(temp.data);
            temp = temp.next;
        }

        allData.add(temp.data);
        return allData;
    }
}