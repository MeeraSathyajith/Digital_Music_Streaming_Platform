import java.io.File;
import java.util.HashMap;
@SuppressWarnings("unused")

public class FileReader
{
    String path = "C:/Users/raama/Music - Copy";

    File folder = new File(path);
    String[] fileNames = folder.list();

    void printFiles()
    {
        for (int i = 0; i < fileNames.length; i++)
        {
            System.out.println((i + 1) + ". " + fileNames[i]);
        }
    }

    HashMap<String, Integer> pairs1 = new HashMap<>();
    HashMap<Integer, String> pairs2 = new HashMap<>();

    void mapFiles()
    {
        for (int i = 0; i < fileNames.length; i++)
        {
            pairs1.put(fileNames[i], i);
        }

        for (int i = 0; i < fileNames.length; i++)
        {
            pairs2.put(i, fileNames[i]);
        }
    }

    void printMap()
    {
        System.out.println(pairs1);
        System.out.println(pairs2);
    }

    void printKey(String name)
    {
        System.out.println(pairs1.get(name));
    }
}