import java.util.List;
@SuppressWarnings("unused")

public class Library
{
    DSALinkedList library = new DSALinkedList();

    void addPlaylist(String playlist)
    {
        library.insertEnd(playlist);
    }

    String searchPlaylist(int position)
    {
        String playlistName = library.getValueAt(position);
        return playlistName;
    }

    int playlistPosition(String song)
    {
        int position = library.searchValuePos(song);
        return position;
    }

    int numberOfPlaylists()
    {
        int size = library.listSize();
        return size;
    }

    void deletePlaylist(String playlist)
    {
        library.deleteValue(playlist);
    }

    void deletePlaylistAt(int position)
    {
        library.deleteAt(position);
    }

    List<String> libraryPlaylists()
    {
        List<String> playlists = library.getAllData();
        return playlists;
    }

}