@SuppressWarnings("unused")

class DSABinarySearchTree
{
    Node root = null;

    Node insertRecur(Node root, Node node)
    {
        int data = node.data;

        if (root == null)
        {
            root = node;
            return root;
        }
        else if (data < root.data)
        {
            root.left = insertRecur(root.left, node);
        }
        else
        {
            root.right = insertRecur(root.right, node);
        }

        return root;
    }

    Node deleteRecur(Node root, int data)
    {
        if (root == null)
        {
            return root;
        }
        else if (root.data > data)
        {
            root.left =  deleteRecur(root.left, data);
        }
        else if (root.data < data)
        {
            root.right =  deleteRecur(root.right, data);
        }
        else
        {
            if (root.left == null && root.right == null)
            {
                root = null;
            }
            else if (root.right != null)
            {
                root.data = next(root);
                root.right = deleteRecur(root.right, root.data);
            }
            else
            {
                root.data = prev(root);
                root.left = deleteRecur(root.left, root.data);
            }
        }

        return root;
    }

    int next(Node root)
    {
        root = root.right;
        while (root.left != null)
        {
            root = root.left;
        }

        return root.data;
    }

    int prev(Node root)
    {
        root = root.left;
        while (root.right != null)
        {
            root = root.right;
        }

        return root.data;
    }

    boolean searchRecur(Node root, int data)
    {
        if (root == null)
        {
            return false;
        }
        else if (root.data == data)
        {
            return true;
        }
        else if (root.data > data)
        {
            return searchRecur(root.left, data);
        }
        else
        {
            return searchRecur(root.right, data);
        }
    }
    
    void displayRecur(Node root)
    {
        if (root != null)
        {
            displayRecur(root.left);
            System.out.println(root.data);
            displayRecur(root.right);
        }
    }

    void insertNode(int data)
    {
        Node node = new Node(data);
        root = insertRecur(root, node);
    }

    void deleteNode(int data)
    {
        if (searchBST(data))
        {
            deleteRecur(root, data);
        }
        else
        {
            System.out.println("Value not found");
        }
    }

    boolean searchBST(int data)
    {
        return searchRecur(root, data);
    }

    void displayBST()
    {
        displayRecur(root);
    }    
}