public class Catalogue
{
    FileReader allSongs = new FileReader();
    DSABinarySearchTree allSongsBST = new DSABinarySearchTree();

    String[] loadCatalogue()
    {
        return allSongs.fileNames;
    }

    void getCatalogue()
    {
        allSongs.printFiles();
    }

    void loadBST()
    {
        for (int i = 0; i < allSongs.fileNames.length; i++)
        {
            allSongsBST.insertNode(i);
        }
    }

    void getBST()
    {
        allSongsBST.displayBST();
    }

    boolean searchSong(String songName)
    {
        int value = allSongs.pairs1.get(songName);
        return allSongsBST.searchBST(value);
    }
}