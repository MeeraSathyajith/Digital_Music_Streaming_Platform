class BSTNode
{
    String data;
    BSTNode left;
    BSTNode right;

    BSTNode(String data)
    {
        this.data = data;
        right = null;
        left = null;
    }
}