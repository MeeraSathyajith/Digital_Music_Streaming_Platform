public class Catalogue
{
    FileReader allSongs = new FileReader();
    DSABinarySearchTree allSongsBST = new DSABinarySearchTree();

    String[] loadCatalogue()
    {
        return allSongs.fileNames;
    }

    void getCatalogue()
    {
        allSongs.printFiles();
    }

    void loadBST()
    {
        for (int i = 0; i < allSongs.fileNames.length; i++)
        {
            allSongsBST.insert(allSongs.fileNames[i]);
        }
    }

    void getBST()
    {
        allSongsBST.inorder();
    }

    boolean searchSong(String songName)
    {
        return allSongsBST.search(songName);
    }
}