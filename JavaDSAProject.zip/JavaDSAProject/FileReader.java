import java.io.File;
@SuppressWarnings("unused")

public class FileReader
{
    String path = "C:/Users/D Praneeth/Desktop/Music - Copy";

    File folder = new File(path);
    String[] fileNames = folder.list();

    String getFullPath(String songName) 
    {
        return path + "/" + songName;
    }
    
    void printFiles()
    {
        for (int i = 0; i < fileNames.length; i++)
        {
            System.out.println((i + 1) + ". " + fileNames[i]);
        }
    }
}