import java.util.List;
@SuppressWarnings("unused")

public class TestMain
{
    public static void main(String[] args)
    {
        Playlist playlist = new Playlist();

        playlist.addSong("Hotel California.mp3");
        playlist.addSong("Clocks.mp3");
        playlist.addSong("Ocean Drive.mp3");
        playlist.addSong("Back To Black.mp3");
        playlist.addSong("Old School.mp3");

        List<String> catalogue = playlist.playlistSongs();
        display(catalogue);

        // playlist.addSongAt("Imagination.mp3", 0);
        // display(playlist.playlistSongs());

        // String value = playlist.searchSong(7);
        // System.out.println(value);

        // int Size = playlist.numberOfSongs();
        // System.out.println(Size);

        // int position = playlist.songPosition("Back To Black.mp3");
        // System.out.println(position);

        //playlist.deleteSongAt(3);
        //playlist.deleteSongAt(1);
        //display(playlist.playlistSongs());
        
        // playlist.deleteSong("Back To Black.mp3");
        // display(playlist.playlistSongs());

//___________________________________________________________

        FileReader filereader = new FileReader();
        filereader.printFiles();
        

//___________________________________________________________

        DSABinarySearchTree bst = new DSABinarySearchTree();

        // bst.insert("Hello");
        // bst.insert("Apple");
        // bst.insert("Raaman");
        // bst.insert("Emerald");
        // bst.insert("5");
        // bst.insert("10");
        // bst.insert("20");
        // bst.inorder();
        // System.out.println();
        // // bst.delete("Raaman");
        // bst.inorder();
        // System.out.println(bst.search("Raaman"));

//___________________________________________________________

        // for (int i = 0; i < filereader.fileNames.length; i++)
        // {
        //     bst.insertNode(i);
        // }

        // for (int i = 0; i < filereader.fileNames.length; i++)
        // {
        //     System.out.println(filereader.pairs2.get(i));
        // }

        // filereader.printFiles();
//___________________________________________________________

        Catalogue cat = new Catalogue();

        // cat.loadCatalogue();
        // cat.getCatalogue();
        // cat.loadBST();
        // cat.getBST();
    }

    private static void display(List<String> songs)
    {
        System.out.println("\nPlaylist songs:");

        for (int i = 0; i < songs.size(); i++)
        {
            System.out.println((i + 1) + ". " + songs.get(i));
        }
        System.out.println();
    }
}