class LLNode
{
    String data;
    LLNode next;

    LLNode(String data)
    {
        this.data = data;
        next = null;
    }
}