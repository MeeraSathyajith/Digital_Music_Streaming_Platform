import java.awt.*;
import java.util.*;
import javax.swing.*;
import javax.swing.border.*;

public class FinalGUI {

    private static DSABinarySearchTree bst = new DSABinarySearchTree();
    private static Library library = new Library();
    private static Map<String, Playlist> playlistMap = new HashMap<>();

    public static void main(String[] args) {
        // === Load Songs into BST ===
        Catalogue cat = new Catalogue();
        for (String song : cat.loadCatalogue()) {
            bst.insert(song);
        }

        // === Main Frame ===
        JFrame frame = new JFrame("Music App");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1100, 650);
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout(10, 10));

        // === Color Scheme ===
        Color backgroundBlack = new Color(20, 20, 20);
        Color panelBlack = new Color(32, 32, 32);
        Color borderGray = Color.GRAY;
        Color textWhite = Color.WHITE;
        Color inputFieldBlack = new Color(28, 28, 28);
        Color accentColor = new Color(0, 150, 136);

        Font defaultFont = new Font("Segoe UI", Font.PLAIN, 14);
        frame.getContentPane().setBackground(backgroundBlack);

        // === Playlist Panel ===
        DefaultListModel<String> playlistListModel = new DefaultListModel<>();
        JList<String> playlistList = new JList<>(playlistListModel);
        playlistList.setFont(defaultFont);
        playlistList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        playlistList.setBorder(new EmptyBorder(10, 10, 10, 10));
        playlistList.setFixedCellHeight(30);
        playlistList.setBackground(panelBlack);
        playlistList.setForeground(textWhite);

        JScrollPane playlistScrollPane = new JScrollPane(playlistList);
        playlistScrollPane.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(borderGray),
                "Library", 0, 0, null, textWhite));
        playlistScrollPane.setBackground(panelBlack);

        // === Buttons for Playlist Panel ===
        JButton createPlaylistButton = new JButton("Create New Playlist");
        createPlaylistButton.setBackground(new Color(33, 150, 243));
        createPlaylistButton.setForeground(Color.WHITE);
        createPlaylistButton.setFocusPainted(false);
        createPlaylistButton.setFont(defaultFont);
        createPlaylistButton.setBorder(new RoundedBorder(new Color(25, 118, 210), 10));
        createPlaylistButton.setOpaque(true);
        createPlaylistButton.setBorderPainted(false);
        createPlaylistButton.setContentAreaFilled(true);
        createPlaylistButton.setPreferredSize(new Dimension(180, 40));

        JButton deletePlaylistButton = new JButton("Delete Playlist");
        deletePlaylistButton.setBackground(new Color(244, 67, 54)); // Red
        deletePlaylistButton.setForeground(Color.WHITE);
        deletePlaylistButton.setFocusPainted(false);
        deletePlaylistButton.setFont(defaultFont);
        deletePlaylistButton.setBorder(new RoundedBorder(new Color(211, 47, 47), 10));
        deletePlaylistButton.setOpaque(true);
        deletePlaylistButton.setBorderPainted(false);
        deletePlaylistButton.setContentAreaFilled(true);
        deletePlaylistButton.setPreferredSize(new Dimension(180, 40));

        JPanel playlistButtonWrapper = new JPanel();
        playlistButtonWrapper.setLayout(new BoxLayout(playlistButtonWrapper, BoxLayout.Y_AXIS));
        playlistButtonWrapper.setBackground(panelBlack);
        playlistButtonWrapper.setBorder(new EmptyBorder(10, 0, 20, 0));

        createPlaylistButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        deletePlaylistButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        playlistButtonWrapper.add(createPlaylistButton);
        playlistButtonWrapper.add(Box.createRigidArea(new Dimension(0, 10)));
        playlistButtonWrapper.add(deletePlaylistButton);

        JPanel playlistPanel = new JPanel(new BorderLayout(10, 10));
        playlistPanel.setPreferredSize(new Dimension(240, 0));
        playlistPanel.setBackground(panelBlack);
        playlistPanel.add(playlistScrollPane, BorderLayout.CENTER);
        playlistPanel.add(playlistButtonWrapper, BorderLayout.SOUTH);

        frame.add(playlistPanel, BorderLayout.WEST);

        // === Songs in Playlist Panel ===
        DefaultListModel<String> songListModel = new DefaultListModel<>();
        JList<String> songList = new JList<>(songListModel);
        songList.setFont(defaultFont);
        songList.setFixedCellHeight(30);
        songList.setBorder(new EmptyBorder(10, 10, 10, 10));
        songList.setBackground(panelBlack);
        songList.setForeground(textWhite);

        JScrollPane songScrollPane = new JScrollPane(songList);
        songScrollPane.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(borderGray),
                "Songs in Playlist", 0, 0, null, textWhite));
        songScrollPane.setBackground(panelBlack);

        JButton removeFromPlaylistButton = new JButton("Remove from Playlist");
        removeFromPlaylistButton.setBackground(new Color(255, 87, 34)); // Orange
        removeFromPlaylistButton.setForeground(Color.WHITE);
        removeFromPlaylistButton.setFocusPainted(false);
        removeFromPlaylistButton.setFont(defaultFont);
        removeFromPlaylistButton.setBorder(new RoundedBorder(new Color(230, 74, 25), 10));
        removeFromPlaylistButton.setOpaque(true);
        removeFromPlaylistButton.setBorderPainted(false);
        removeFromPlaylistButton.setContentAreaFilled(true);
        removeFromPlaylistButton.setPreferredSize(new Dimension(180, 40));

        JPanel songsPanel = new JPanel(new BorderLayout(10, 10));
        songsPanel.setPreferredSize(new Dimension(300, 0));
        songsPanel.setBackground(panelBlack);
        songsPanel.add(songScrollPane, BorderLayout.CENTER);

        JPanel songButtonWrapper = new JPanel();
        songButtonWrapper.setBackground(panelBlack);
        songButtonWrapper.setBorder(new EmptyBorder(10, 10, 10, 10));
        songButtonWrapper.add(removeFromPlaylistButton);
        songsPanel.add(songButtonWrapper, BorderLayout.SOUTH);

        frame.add(songsPanel, BorderLayout.EAST);

        // === Center Panel ===
        JPanel centerPanel = new JPanel(new GridBagLayout());
        centerPanel.setBackground(panelBlack);
        centerPanel.setBorder(new CompoundBorder(
                new EmptyBorder(20, 30, 20, 30),
                new LineBorder(borderGray, 1, true)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel searchLabel = new JLabel("Search a Song:");
        searchLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        searchLabel.setForeground(textWhite);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 3;
        gbc.anchor = GridBagConstraints.WEST;
        centerPanel.add(searchLabel, gbc);

        JTextField searchField = new JTextField(25);
        searchField.setFont(defaultFont);
        searchField.setBackground(inputFieldBlack);
        searchField.setForeground(textWhite);
        searchField.setCaretColor(textWhite);
        searchField.setBorder(new RoundedBorder(borderGray, 10));
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        centerPanel.add(searchField, gbc);

        JButton searchButton = new JButton("Search");
        searchButton.setBackground(accentColor);
        searchButton.setForeground(Color.WHITE);
        searchButton.setFocusPainted(false);
        searchButton.setFont(defaultFont);
        searchButton.setBorder(new RoundedBorder(accentColor.darker(), 10));
        searchButton.setOpaque(true);
        searchButton.setBorderPainted(false);
        searchButton.setContentAreaFilled(true);
        searchButton.setPreferredSize(new Dimension(100, 40));
        gbc.gridx = 2;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.NONE;
        centerPanel.add(searchButton, gbc);

        JLabel resultLabel = new JLabel(" ");
        resultLabel.setFont(defaultFont);
        resultLabel.setForeground(textWhite);
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 3;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        centerPanel.add(resultLabel, gbc);

        JComboBox<String> playlistDropdown = new JComboBox<>();
        playlistDropdown.setFont(defaultFont);
        playlistDropdown.setBackground(Color.WHITE);
        playlistDropdown.setForeground(Color.BLACK);
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        centerPanel.add(playlistDropdown, gbc);

        JButton addToPlaylistButton = new JButton("Add to Selected Playlist");
        addToPlaylistButton.setBackground(new Color(76, 175, 80));
        addToPlaylistButton.setForeground(Color.WHITE);
        addToPlaylistButton.setFocusPainted(false);
        addToPlaylistButton.setFont(defaultFont);
        addToPlaylistButton.setBorder(new RoundedBorder(new Color(56, 142, 60), 10));
        addToPlaylistButton.setOpaque(true);
        addToPlaylistButton.setBorderPainted(false);
        addToPlaylistButton.setContentAreaFilled(true);
        addToPlaylistButton.setPreferredSize(new Dimension(150, 40));
        gbc.gridy = 4;
        gbc.gridwidth = 3;
        centerPanel.add(addToPlaylistButton, gbc);

        frame.add(centerPanel, BorderLayout.CENTER);

        // === Default Playlists ===
        createDefaultPlaylists(playlistListModel, playlistDropdown);

        // === Listeners ===
        searchButton.addActionListener(e -> {
            String song = searchField.getText().trim();
            if (song.isEmpty()) return;

            boolean found = bst.search(song);
            if (found) {
                resultLabel.setText("Found: " + song);
                resultLabel.setForeground(accentColor);
            } else {
                resultLabel.setText("Not Found: " + song);
                resultLabel.setForeground(Color.RED);
            }
        });

        createPlaylistButton.addActionListener(e -> {
            String name = JOptionPane.showInputDialog(frame, "Enter Playlist Name:");
            if (name != null && !name.trim().isEmpty()) {
                String trimmed = name.trim();
                if (playlistMap.containsKey(trimmed)) {
                    JOptionPane.showMessageDialog(frame, "Playlist already exists!");
                    return;
                }
                addPlaylist(trimmed);
                playlistListModel.addElement(trimmed);
                refreshPlaylistDropdown(playlistDropdown);
            }
        });

        deletePlaylistButton.addActionListener(e -> {
            String selected = playlistList.getSelectedValue();
            if (selected != null && !selected.equals("All Songs")) {
                int confirm = JOptionPane.showConfirmDialog(frame,
                        "Are you sure you want to delete playlist: " + selected + "?",
                        "Confirm Delete", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    playlistMap.remove(selected);
                    library.deletePlaylist(selected);
                    playlistListModel.removeElement(selected);
                    refreshPlaylistDropdown(playlistDropdown);
                    songListModel.clear();
                }
            } else {
                JOptionPane.showMessageDialog(frame, "Cannot delete catalogue.");
            }
        });

        addToPlaylistButton.addActionListener(e -> {
            String song = searchField.getText().trim();
            String selectedPlaylist = (String) playlistDropdown.getSelectedItem();

            if (song.isEmpty() || selectedPlaylist == null) return;

            if (bst.search(song)) {
                Playlist playlist = playlistMap.get(selectedPlaylist);
                if (playlist.playlistSongs().contains(song)) {
                    resultLabel.setText("Song already in playlist!");
                    resultLabel.setForeground(Color.RED);
                } else {
                    playlist.addSong(song);
                    resultLabel.setText("Added to playlist: " + selectedPlaylist);
                    resultLabel.setForeground(accentColor);

                    if (selectedPlaylist.equals(playlistList.getSelectedValue())) {
                        updateSongList(songListModel, playlist);
                    }
                }
            } else {
                resultLabel.setText("Song not found in catalogue.");
                resultLabel.setForeground(Color.RED);
            }
        });

        // [All your existing imports and class definitions above stay the same]

        removeFromPlaylistButton.addActionListener(e -> {
            String selectedPlaylist = playlistList.getSelectedValue();
            String selectedSong = songList.getSelectedValue();

            if (selectedPlaylist == null || selectedSong == null) {
                JOptionPane.showMessageDialog(frame, "Please select both a playlist and a song.");
                return;
            }

            Playlist playlist = playlistMap.get(selectedPlaylist);
            if (playlist != null && playlist.playlistSongs().contains(selectedSong)) {
                playlist.deleteSong(selectedSong);
                updateSongList(songListModel, playlist);
                resultLabel.setText("Removed from playlist: " + selectedPlaylist);
                resultLabel.setForeground(Color.ORANGE);
            }
        });

        // === Update remove button based on selection dynamically ===
        songList.addListSelectionListener(e -> {
            String selectedPlaylist = playlistList.getSelectedValue();
            String selectedSong = songList.getSelectedValue();
            boolean isAllSongs = "All Songs".equals(selectedPlaylist);

            removeFromPlaylistButton.setEnabled(
                selectedPlaylist != null && selectedSong != null && !isAllSongs
            );
        });

        playlistList.addListSelectionListener(e -> {
            String selected = playlistList.getSelectedValue();
            if (selected != null && playlistMap.containsKey(selected)) {
                updateSongList(songListModel, playlistMap.get(selected));
            }

            String selectedSong = songList.getSelectedValue();
            boolean isAllSongs = "All Songs".equals(selected);

            removeFromPlaylistButton.setEnabled(
                selected != null && selectedSong != null && !isAllSongs
            );
        });

        // 🎵 Play song only on double-click
        songList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                if (evt.getClickCount() == 2) {
                    String selectedSong = songList.getSelectedValue();
                    String songPath = "C:/Users/D Praneeth/Desktop/Music - Copy/" + selectedSong;
                    AudioPlayer.openAudioFile(songPath);
                }
            }
        });

        frame.setVisible(true);
    }

    private static void addPlaylist(String name) {
        library.addPlaylist(name);
        playlistMap.put(name, new Playlist());
    }

    private static void refreshPlaylistDropdown(JComboBox<String> dropdown) {
        dropdown.removeAllItems();
        for (String name : library.libraryPlaylists()) {
            dropdown.addItem(name);
        }
    }

    private static void updateSongList(DefaultListModel<String> model, Playlist playlist) {
        model.clear();
        java.util.List<String> songs = playlist.playlistSongs();
        for (String song : songs) {
            model.addElement(song);
        }
    }

    private static void createDefaultPlaylists(DefaultListModel<String> playlistListModel, JComboBox<String> playlistDropdown) {
        Playlist allSongsPlaylist = new Playlist();
        Catalogue cat = new Catalogue();
        for (String song : cat.loadCatalogue()) {
            allSongsPlaylist.addSong(song);
        }
        playlistMap.put("All Songs", allSongsPlaylist);
        library.addPlaylist("All Songs");
        playlistListModel.addElement("All Songs");

        Playlist favouritesPlaylist = new Playlist();
        playlistMap.put("Favourites", favouritesPlaylist);
        library.addPlaylist("Favourites");
        playlistListModel.addElement("Favourites");

        refreshPlaylistDropdown(playlistDropdown);
    }
    
    // === Custom Rounded Border Class ===
    static class RoundedBorder extends AbstractBorder {
        private Color color;
        private int radius;

        public RoundedBorder(Color color, int radius) {
            this.color = color;
            this.radius = radius;
        }

        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            g.setColor(color);
            g.drawRoundRect(x, y, width - 1, height - 1, radius, radius);
        }

        @Override
        public Insets getBorderInsets(Component c) {
            return new Insets(this.radius + 1, this.radius + 1, this.radius + 1, this.radius + 1);
        }
    }
}