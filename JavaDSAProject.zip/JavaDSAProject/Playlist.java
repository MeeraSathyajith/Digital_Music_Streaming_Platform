import java.util.List;
@SuppressWarnings("unused")

public class Playlist
{
    DSALinkedList playlist = new DSALinkedList();

    void addSong(String song)
    {
        playlist.insertEnd(song);
    }

    void addSongAt(String song, int position)
    {
        playlist.insertAt(song, position);
    }

    String searchSong(int position)
    {
        String songName = playlist.getValueAt(position);
        return songName;
    }

    int numberOfSongs()
    {
        int size = playlist.listSize();
        return size + 1;
    }
 
 
    int songPosition(String song)
    {
        int position = playlist.searchValuePos(song);
        return position;
    }

    void deleteSong(String song)
    {
        playlist.deleteValue(song);
    }

    void deleteSongAt(int position)
    {
        playlist.deleteAt(position);
    }

    List<String> playlistSongs()
    {
        List<String> songs = playlist.getAllData();
        return songs;
    }
}