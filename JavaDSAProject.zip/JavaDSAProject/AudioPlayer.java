import java.awt.Desktop;
import java.io.File;
import java.io.IOException;

public class AudioPlayer 
{

    public static void openAudioFile(String songPath) 
    {
        try 
        {
            if (Desktop.isDesktopSupported()) 
            {
                Desktop desktop = Desktop.getDesktop();
                File file = new File(songPath);
                
                if (file.exists()) 
                {
                    desktop.open(file);
                } 
                else 
                {
                    System.out.println("File not found: " + songPath);
                }
            } 
            else 
            {
                System.out.println("Desktop is not supported on this platform.");
            }
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
            System.out.println("Error opening audio file: " + e.getMessage());
        }
    }
}
