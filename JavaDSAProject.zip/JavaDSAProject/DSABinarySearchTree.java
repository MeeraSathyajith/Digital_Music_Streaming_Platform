public class DSABinarySearchTree {

    private BSTNode root;

    // Insert a new string
    public void insert(String value) {
        root = insertRec(root, value);
    }

    private BSTNode insertRec(BSTNode root, String value) {
        if (root == null) return new BSTNode(value);

        if (value.compareTo(root.data) < 0) {
            root.left = insertRec(root.left, value);
        } else if (value.compareTo(root.data) > 0) {
            root.right = insertRec(root.right, value);
        }
        return root;
    }

    // Search for a string
    public boolean search(String value) {
        return searchRec(root, value);
    }

    private boolean searchRec(BSTNode root, String value) {
        if (root == null) return false;
        if (value.equals(root.data)) return true;
        if (value.compareTo(root.data) < 0) {
            return searchRec(root.left, value);
        } else {
            return searchRec(root.right, value);
        }
    }

    // Delete a string
    public void delete(String value) {
        root = deleteRec(root, value);
    }

    private BSTNode deleteRec(BSTNode root, String value) {
        if (root == null) return null;

        if (value.compareTo(root.data) < 0) {
            root.left = deleteRec(root.left, value);
        } else if (value.compareTo(root.data) > 0) {
            root.right = deleteRec(root.right, value);
        } else {
            // Node found
            if (root.left == null)
                return root.right;
            else if (root.right == null)
                return root.left;

            // Node with two children: get inorder successor (smallest in the right subtree)
            root.data = minValue(root.right);
            root.right = deleteRec(root.right, root.data);
        }
        return root;
    }

    private String minValue(BSTNode root) {
        String min = root.data;
        while (root.left != null) {
            root = root.left;
            min = root.data;
        }
        return min;
    }

    // In-order traversal
    public void inorder() {
        inorderRec(root);
    }

    private void inorderRec(BSTNode root) {
        if (root != null) {
            inorderRec(root.left);
            System.out.println(root.data);
            inorderRec(root.right);
        }
    }
}
